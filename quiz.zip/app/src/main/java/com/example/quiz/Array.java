package com.example.quiz;

public class Array {


    //массив для первого ур
    final int[] imagest1 = {
            R.drawable.zero,
            R.drawable.one___one,
            R.drawable.two_t,
            R.drawable.thre,
            R.drawable.tho,
            R.drawable.fife,
            R.drawable.six,
            R.drawable.seven,
            R.drawable.asa,
            R.drawable.gg,
    };

    final int[] texts1 ={
            R.string.lvltext0,
            R.string.lvltext1,
            R.string.lvltext2,
            R.string.lvltext3,
            R.string.lvltext4,
            R.string.lvltext5,
            R.string.lvltext6,
            R.string.lvltext7,
            R.string.lvltext8,
            R.string.lvltext9,



    };

    



    //конец
    //массив для первого ур
    final int[] imagest2 = {
            R.drawable.l,
            R.drawable.a,
            R.drawable.b,
            R.drawable.c,
            R.drawable.e,
            R.drawable.f,
            R.drawable.g,
            R.drawable.h,
            R.drawable.i,
            R.drawable.k,
    };

    final int[] texts2 ={
            R.string.lvl2text0,
            R.string.lvl2text1,
            R.string.lvl2text2,
            R.string.lvl2text3,
            R.string.lvl2text4,
            R.string.lvl2text5,
            R.string.lvl2text6,
            R.string.lvl2text7,
            R.string.lvl2text8,
            R.string.lvl2text9,



    };

    final int[] imagest3 = {
            R.drawable.og,
            R.drawable.gb,
            R.drawable.tr,
            R.drawable.cet,
            R.drawable.pi,
            R.drawable.sh,
            R.drawable.sem,
            R.drawable.bos,
            R.drawable.geb,
            R.drawable.ten,
    };

    final int[] texts3 ={
            R.string.lvl3text0,
            R.string.lvl3text1,
            R.string.lvl3text2,
            R.string.lvl3text3,
            R.string.lvl3text4,
            R.string.lvl3text5,
            R.string.lvl3text6,
            R.string.lvl3text7,
            R.string.lvl3text8,
            R.string.lvl3text9,



    };

    final int[] imagest4 = {
            R.drawable.stek,
            R.drawable.steka,
            R.drawable.stekb,
            R.drawable.stekc,
            R.drawable.stekd,
            R.drawable.steke,
            R.drawable.stekf,
            R.drawable.stekg,
            R.drawable.stekh,
            R.drawable.steki,
    };

    final int[] texts4 = {
            R.string.lvl4text0,
            R.string.lvl4text1,
            R.string.lvl4text2,
            R.string.lvl4text3,
            R.string.lvl4text4,
            R.string.lvl4text5,
            R.string.lvl4text6,
            R.string.lvl4text7,
            R.string.lvl4text8,
            R.string.lvl4text9,

    };


    final int[] imagest5 = {
            R.drawable.smile,
            R.drawable.smilea,
            R.drawable.smileb,
            R.drawable.smilec,
            R.drawable.smiled,
            R.drawable.smilee,
            R.drawable.smilef,
            R.drawable.smileg,
            R.drawable.smileh,
            R.drawable.smilei,
    };

    final int[] texts5 ={
            R.string.lvl5text0,
            R.string.lvl5text1,
            R.string.lvl5text2,
            R.string.lvl5text3,
            R.string.lvl5text4,
            R.string.lvl5text5,
            R.string.lvl5text6,
            R.string.lvl5text7,
            R.string.lvl5text8,
            R.string.lvl5text9,




    };


    final int[] imagest6 = {
            R.drawable.gg,
            R.drawable.asa,
            R.drawable.seven,
            R.drawable.six ,
            R.drawable.fife ,
            R.drawable.tho ,
            R.drawable.thre,
            R.drawable.two_t ,
            R.drawable.one___one,
            R.drawable.zero,
    };

    final int[] texts6 ={
            R.string.lvl6text0,
            R.string.lvl6text1,
            R.string.lvl6text2,
            R.string.lvl6text3,
            R.string.lvl6text4,
            R.string.lvl6text5,
            R.string.lvl6text6,
            R.string.lvl6text7,
            R.string.lvl6text8,
            R.string.lvl6text9,



    };

    final int[] imagest7 = {
            R.drawable.k,
            R.drawable.i,
            R.drawable.h,
            R.drawable.g,
            R.drawable.f,
            R.drawable.e,
            R.drawable.c,
            R.drawable.b,
            R.drawable.a,
            R.drawable.l,
    };

    final int[] texts7 ={
            R.string.lvl7text0,
            R.string.lvl7text1,
            R.string.lvl7text2,
            R.string.lvl7text3,
            R.string.lvl7text4,
            R.string.lvl7text5,
            R.string.lvl7text6,
            R.string.lvl7text7,
            R.string.lvl7text8,
            R.string.lvl7text9,



    };

    final int[] imagest8 = {
            R.drawable.ten,
            R.drawable.geb,
            R.drawable.bos,
            R.drawable.sem,
            R.drawable.sh,
            R.drawable.pi,
            R.drawable.cet,
            R.drawable.tr,
            R.drawable.gb,
            R.drawable.og,
    };

    final int[] texts8 ={
            R.string.lvl8text0,
            R.string.lvl8text1,
            R.string.lvl8text2,
            R.string.lvl8text3,
            R.string.lvl8text4,
            R.string.lvl8text5,
            R.string.lvl8text6,
            R.string.lvl8text7,
            R.string.lvl8text8,
            R.string.lvl8text9,



    };
    final int[] imagest9 = {
            R.drawable.steki,
            R.drawable.stekh,
            R.drawable.stekg,
            R.drawable.stekf,
            R.drawable.steke,
            R.drawable.stekd,
            R.drawable.stekc,
            R.drawable.stekb,
            R.drawable.steka,
            R.drawable.stek,
    };

    final int[] texts9 = {
            R.string.lvl9text0,
            R.string.lvl9text1,
            R.string.lvl9text2,
            R.string.lvl9text3,
            R.string.lvl9text4,
            R.string.lvl9text5,
            R.string.lvl9text6,
            R.string.lvl9text7,
            R.string.lvl9text8,
            R.string.lvl9text9,

    };

    final int[] imagest10 = {
            R.drawable.smilei,
            R.drawable.smileh,
            R.drawable.smileg,
            R.drawable.smilef,
            R.drawable.smilee,
            R.drawable.smiled,
            R.drawable.smilec,
            R.drawable.smileb,
            R.drawable.smilea,
            R.drawable.smile,
    };

    final int[] texts10 ={
            R.string.lvl10text0,
            R.string.lvl10text1,
            R.string.lvl10text2,
            R.string.lvl10text3,
            R.string.lvl10text4,
            R.string.lvl10text5,
            R.string.lvl10text6,
            R.string.lvl10text7,
            R.string.lvl10text8,
            R.string.lvl10text9,




    };



    //конец
}

